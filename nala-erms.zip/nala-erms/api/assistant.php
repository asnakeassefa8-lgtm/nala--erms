<?php
// api/assistant.php
// In-app help assistant for the NALA ERMS workflow.
require_once '../includes/functions.php';
requireLogin();
header('Content-Type: application/json; charset=utf-8');

$question = trim($_POST['question'] ?? '');
if ($question === '') {
    echo json_encode(['success' => false, 'message' => 'Please enter a question.']);
    exit;
}

$questionLower = strtolower($question);
$stats = getDashboardStats();
$hasAny = static function (array $terms) use ($questionLower): bool {
    foreach ($terms as $term) if (strpos($questionLower, $term) !== false) return true;
    return false;
};

$answer = '';
if ($hasAny(['hello', 'hi ', 'hey', 'good morning', 'good afternoon', 'good evening'])) {
    $answer = "Hello! I am the NALA ERMS Assistant. I can guide you through records, workflow, review, archive, search, reports, users, and settings. What would you like to do?";
} elseif ($hasAny(['about the project', 'about project', 'what is this project', 'system overview', 'project overview', 'all project', 'what can this system do'])) {
    $answer = "NALA ERMS is the National Archive and Library Services Enhanced Records Management System. It manages the complete document lifecycle:\n\n1. Capture: register incoming letters, outgoing letters, and internal memos with reference details and attachments.\n2. Route: assign a receiver and notify the responsible user.\n3. Review: authorized reviewers inspect details and attachments, add remarks, sign digitally, and approve or reject.\n4. Track: use status, notifications, workflow, search, QR codes, and the Audit Trail.\n5. Preserve: approved and rejected documents are saved in the Archive.\n6. Report: authorized users can generate daily, monthly, workflow, and compliance reports.\n\nYour available pages and actions depend on your assigned role. Use the sidebar to open the relevant module.";
} elseif ($hasAny(['list of incoming', 'list incoming', 'incoming letters list', 'show incoming', 'view incoming'])) {
    $answer = "To view incoming letters:\n1. Open Incoming Letters from the sidebar.\n2. The table shows reference, sender unique number, title, sender, receiver, attachment, status, date, QR code, and actions.\n3. Select View for the full record.\n4. Select Review when authorized, or Edit when your role allows it.\n\nCurrent total: " . (int) ($stats['incoming_count'] ?? 0) . " incoming letter(s). Use Search to filter by reference, sender, receiver, title, keyword, date, or status.";
} elseif ($hasAny(['list of outgoing', 'list outgoing', 'outgoing letters list', 'show outgoing', 'view outgoing'])) {
    $answer = "To view outgoing letters:\n1. Open Outgoing Letters from the sidebar.\n2. The table shows reference, title, receiver, classification, status, date, and actions.\n3. Select View for the full record and attachment.\n4. Select Review to approve or reject when authorized.\n5. After approval, an authorized records user can Dispatch the letter.\n\nCurrent total: " . (int) ($stats['outgoing_count'] ?? 0) . " outgoing letter(s).";
} elseif ($hasAny(['list of internal', 'list internal', 'internal memo list', 'show internal', 'view internal', 'list memo'])) {
    $answer = "To view internal memos:\n1. Open Internal Memos from the sidebar.\n2. The table shows reference, title, receiver, status, date, and actions.\n3. Select View to read the memo and open its attachment.\n4. Select Review to approve or reject when authorized.\n5. Select Edit when your role allows it.\n\nCurrent total: " . (int) ($stats['internal_count'] ?? 0) . " internal memo(s).";
} elseif ($hasAny(['incoming']) && $hasAny(['add', 'new', 'create', 'register', 'receive', 'how'])) {
    $answer = "How to add an incoming letter:\n1. Open Incoming Letters.\n2. Click New Incoming Letter.\n3. Enter the reference number, sender unique number, title, description, sender, receiver, receiver email, classification, keywords, and received date.\n4. Add the attachment when available.\n5. Check the information and click Save & Send.\n\nThe record is created with pending status, the receiver is notified, and authorized users can review it. Keep the reference number unique and use a clear title and classification.";
} elseif ($hasAny(['outgoing']) && $hasAny(['add', 'new', 'create', 'register', 'send', 'how'])) {
    $answer = "How to add an outgoing letter:\n1. Open Outgoing Letters.\n2. Click New Outgoing Letter.\n3. Enter the reference number, title, description, sender, receiver, receiver email, classification, date, and attachment.\n4. Confirm the recipient and date, then click Save & Send.\n\nThe letter is submitted with pending approval status. The reviewer is notified. After approval, an authorized records user can dispatch it.";
} elseif ($hasAny(['memo', 'internal']) && $hasAny(['add', 'new', 'create', 'register', 'send', 'how'])) {
    $answer = "How to add an internal memo:\n1. Open Internal Memos.\n2. Click New Internal Memo.\n3. Enter the reference number, date, title, description, sender, receiver, receiver email, and attachment.\n4. Review the details and click Save & Send.\n\nThe memo is routed to the selected receiver and remains available for authorized review.";
} elseif ($hasAny(['edit', 'update', 'change', 'modify'])) {
    $answer = "How to edit a document:\n1. Open Incoming Letters, Outgoing Letters, or Internal Memos.\n2. Find the record and click Edit.\n3. Update the permitted fields and optionally replace the attachment.\n4. Submit the form to save the changes.\n\nEditing is restricted by role and workflow status. The system records the latest editor, time, and update action in the Audit Trail.";
} elseif ($hasAny(['review', 'approve', 'reject', 'sign', 'signature'])) {
    $answer = "How to review a letter or memo:\n1. Open the relevant record list.\n2. Click Review on a pending document assigned to you.\n3. Read the details and open the attachment.\n4. Add a clear review remark when necessary.\n5. Draw your digital signature in the signature box.\n6. Click Approve or Reject and confirm.\n\nThe system saves the decision, reviewer, remark, signature, and date. Approved or rejected documents are preserved in the Archive. If Review is not shown, your role or the status does not allow it.";
} elseif ($hasAny(['archive', 'archived', 'preserve', 'records management'])) {
    $answer = "About the Archive:\nApproved and rejected incoming letters, outgoing letters, and internal memos are automatically preserved in the Archive. Open Archive from the sidebar to search by reference, title, or status, then select Open to inspect the archived record and attachment.\n\nArchive access depends on your role. Handle archived records according to your records-management policy and do not delete or alter them without authorization.";
} elseif ($hasAny(['how many', 'count', 'number of', 'statistics', 'stats', 'summary'])) {
    $answer = "Current system summary:\n- Incoming letters: " . (int) ($stats['incoming_count'] ?? 0) . "\n- Outgoing letters: " . (int) ($stats['outgoing_count'] ?? 0) . "\n- Internal memos: " . (int) ($stats['internal_count'] ?? 0) . "\n- Documents waiting for review: " . ((int) ($stats['pending_incoming'] ?? 0) + (int) ($stats['pending_outgoing'] ?? 0) + (int) ($stats['pending_internal'] ?? 0));
} elseif ($hasAny(['search', 'find', 'locate'])) {
    $answer = "To search records:\n1. Open Search from the sidebar.\n2. Enter a reference number, title, sender, receiver, keyword, or description.\n3. Choose Incoming, Outgoing, Internal, Archive, or All record types.\n4. Open a result to view its details and attachment.";
} elseif ($hasAny(['audit', 'history', 'who edited', 'edited by', 'activity'])) {
    $answer = "Open Audit Trail to review recorded actions, users, roles, details, dates, times, IP addresses, and user agents. Document updates are recorded as Incoming Letter Updated, Outgoing Letter Updated, or Internal Memo Updated. The document details also show the latest editor when available.";
} elseif ($hasAny(['notification', 'notified', 'alert'])) {
    $answer = "Open Notifications from the top bar to see workflow updates and messages sent to your account. Select a notification to follow its related record. Receivers are notified when a document is submitted, and workflow actions may generate additional notifications.";
} elseif ($hasAny(['report', 'reporting'])) {
    $answer = "Open Reports to generate a Daily Register, Monthly Summary, Workflow Performance report, or Compliance report. Choose the required filters, generate the report, and review the preview. Report access depends on your role.";
} elseif ($hasAny(['workflow', 'rule'])) {
    $answer = "Open Workflow to manage workflow rules when your role permits it. Rules can react to a document being submitted, approved, or rejected and can notify a receiver, notify the sender, or send an email. Use workflow rules to keep routing and follow-up consistent.";
} elseif ($hasAny(['user', 'account', 'password', 'profile', 'role'])) {
    $answer = "Open Settings to update your profile, photo, contact details, or password. Administrators can use Users to add, edit, activate, deactivate, or reset user accounts. Pages and actions are controlled by the assigned role.";
} elseif ($hasAny(['view', 'open', 'attachment', 'document'])) {
    $answer = "To view a document, open its record list and select View or click its QR code. The details window can show the reference, sender, receiver, status, date, description, attachment, remarks, signature, and latest editor.";
} else {
    $answer = "I can help with NALA ERMS. Try asking:\n\n- How do I list incoming letters?\n- How do I add an outgoing letter?\n- How do I create an internal memo?\n- How do I review, approve, or reject a letter?\n- How do I edit a document?\n- How does the Archive work?\n- What is the complete project workflow?\n- How do I search, dispatch, report, or check the Audit Trail?";
}

echo json_encode(['success' => true, 'answer' => $answer], JSON_UNESCAPED_UNICODE);
